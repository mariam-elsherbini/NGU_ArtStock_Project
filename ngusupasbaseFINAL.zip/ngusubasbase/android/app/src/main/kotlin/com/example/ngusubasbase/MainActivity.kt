package com.example.ngusubasbase

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
