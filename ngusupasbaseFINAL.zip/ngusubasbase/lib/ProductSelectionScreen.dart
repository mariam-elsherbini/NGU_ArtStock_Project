import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProductSelectionScreen extends StatefulWidget {
  final List<String> selectedStudentIds;

  const ProductSelectionScreen({required this.selectedStudentIds, super.key});

  @override
  State<ProductSelectionScreen> createState() => _ProductSelectionScreenState();
}

class _ProductSelectionScreenState extends State<ProductSelectionScreen> {
  String? selectedProductId;
  int quantity = 1;
  List<Map<String, dynamic>> products = [];

  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  Future<void> fetchProducts() async {
    final response = await Supabase.instance.client.from('products').select();
    setState(() {
      products = List<Map<String, dynamic>>.from(response);
      if (products.isNotEmpty) selectedProductId = products.first['id'].toString();
    });
  }

  Future<void> addItemToStudentsCart() async {
    if (selectedProductId == null) return;

    for (String studentId in widget.selectedStudentIds) {
      await Supabase.instance.client.from('cart_items').insert({
        'user_id': studentId,
        'product_id': selectedProductId,
        'quantity': quantity,
      });
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text('Item added to ${widget.selectedStudentIds.length} student(s) cart!')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Product')),
      body: products.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButton<String>(
              value: selectedProductId,
              items: products.map((p) {
                return DropdownMenuItem<String>(
                  value: p['id'].toString(),
                  child: Text(p['name'] ?? 'Unnamed'),
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedProductId = val;
                });
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    if (quantity > 1) setState(() => quantity--);
                  },
                ),
                Text(quantity.toString(), style: const TextStyle(fontSize: 18)),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() => quantity++);
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: addItemToStudentsCart,
              child: const Text('Add to Cart for Selected Students'),
            ),
          ],
        ),
      ),
    );
  }
}
