import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'OrderHistoryScreen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  Future<List<dynamic>> fetchCartItems() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];

    final response = await Supabase.instance.client
        .from('cart_items')
        .select('*, products(*)')
        .eq('user_id', user.id);

    return response;
  }

  Future<void> removeItem(String cartItemId) async {
    await Supabase.instance.client
        .from('cart_items')
        .delete()
        .eq('id', cartItemId);
    setState(() {});
  }

  Future<void> checkout(List<dynamic> cartItems) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || cartItems.isEmpty) return;

    double total = 0;
    for (var item in cartItems) {
      total += (item['products']['price'] ?? 0) * item['quantity'];
    }

    final orderResponse = await Supabase.instance.client
        .from('orders')
        .insert({'user_id': user.id, 'total': total}).select().single();

    final orderId = orderResponse['id'];

    for (var item in cartItems) {
      await Supabase.instance.client.from('order_items').insert({
        'order_id': orderId,
        'product_id': item['product_id'],
        'quantity': item['quantity'],
      });
    }

    await Supabase.instance.client
        .from('cart_items')
        .delete()
        .eq('user_id', user.id);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Order placed successfully!")),
    );

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Your Cart")),
      body: FutureBuilder<List<dynamic>>(
        future: fetchCartItems(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: \${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Your cart is empty."));
          }

          final cartItems = snapshot.data!;
          double total = 0;
          for (var item in cartItems) {
            total += (item['products']['price'] ?? 0) * item['quantity'];
          }

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final item = cartItems[index];
                    return ListTile(
                      leading: Image.network(item['products']['image_url'], width: 50, height: 50),
                      title: Text(item['products']['name']),
                      subtitle: Text('Qty: ${item['quantity']} - \$${item['products']['price']}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => removeItem(item['id']),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Total: \$${total.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => checkout(cartItems),
                        child: const Text("Place Order"),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Add your Order History button here:
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'View Order History',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }
}
