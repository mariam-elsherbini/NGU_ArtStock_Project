import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'cart.dart';
import 'wishlist.dart';
import 'account.dart';

class StaffScreen extends StatefulWidget {
  final String username;
  const StaffScreen({super.key, required this.username});

  @override
  State<StaffScreen> createState() => _StaffScreenState();
}

class _StaffScreenState extends State<StaffScreen> {
  final PageController _pageController = PageController(viewportFraction: 0.9);
  final PageController _popularController = PageController(viewportFraction: 0.4);
  int _currentPage = 0;
  int _popularIndex = 0;
  bool _viewingCategory = false;
  List<Map<String, dynamic>> _categoryProducts = [];
  String _currentCategoryName = '';

  final List<Map<String, String>> categoryData = [
    {'id': '1', 'label': 'Pencils', 'url': 'https://th.bing.com/th/id/OIP.fzJPZr1N4Y_Xz0A_26QJOAHaHa?rs=1&pid=ImgDetMain'},
    {'id': '2', 'label': 'Sketchbooks', 'url': 'https://th.bing.com/th/id/OIP.ArigPRkVVUThSkmCA8GmQgHaHa?rs=1&pid=ImgDetMain'},
    {'id': '3', 'label': 'Paint Colors', 'url': 'https://th.bing.com/th/id/R.68844cd1fb304f37a2a1f6595ae44eef?rik=bS96q3a%2fU7Ne2g&riu=http%3a%2f%2fgratefulgrumbles.com%2fwp-content%2fuploads%2f2017%2f05%2fcropped-IMG_1277-1.jpg&ehk=TAQjsQIh9s%2bop4%2fujCaUQixSyNwcb0yDa0HilJq1OM0%3d&risl=&pid=ImgRaw&r=0'},
    {'id': '4', 'label': 'Rulers', 'url': 'https://th.bing.com/th/id/R.0a879794f06c82d03dd597a7386114b5?rik=TvFnBsAefY39HQ&riu=http%3a%2f%2fwww.omghowcheap.co.uk%2fekmps%2fshops%2fomghowcheap%2fimages%2f12-coloured-rulers-pack-of-12-shatter-resistant-plastic-30cm-rulers-mixed-8803-p.jpg&ehk=dbD1gb%2fFulR6WqIU%2fu4Djv%2biFakx6zz8PNpWqLK8ZmU%3d&risl=&pid=ImgRaw&r=0'},
    {'id': '5', 'label': 'Crayons', 'url': 'https://th.bing.com/th/id/OIP.m6rSUa4t8rol9YzYkPgxHwHaE7?rs=1&pid=ImgDetMain'},
    {'id': '6', 'label': 'Highlighters', 'url': 'https://m.media-amazon.com/images/I/91T98vSMUtS.AC_SL1500.jpg'},
  ];

  List<Map<String, dynamic>> fetchedPopularPicks = [];
  Set<String> wishlistItemIds = {};
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> searchResults = [];
  bool isSearching = false;
  List<Map<String, dynamic>> _users = [];

  @override
  void initState() {
    super.initState();
    _fetchPopularPicks();
    _fetchWishlist();
    _fetchUsers();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _pageController.dispose();
    _popularController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults = [];
      });
    } else {
      _searchProducts(query);
    }
  }

  Future<void> _fetchUsers() async {
    try {
      final currentUser = Supabase.instance.client.auth.currentUser;
      if (currentUser == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No user logged in')),
          );
        }
        return;
      }

      // Get staff profile
      final staffResponse = await Supabase.instance.client
          .from('profiles')
          .select('id, username')
          .eq('id', currentUser.id);

      final staffProfile = (staffResponse as List).first as Map<String, dynamic>;

      // Get all student_ids for this staff from the relationship table
      final relationshipsResponse = await Supabase.instance.client
          .from('student_staff_relationships')
          .select('student_id')
          .eq('staff_id', currentUser.id);

      final relationships = (relationshipsResponse as List).cast<Map<String, dynamic>>();
      final studentIds = relationships.map((r) => r['student_id'].toString()).toList();

      // Fetch all student profiles
      List<Map<String, dynamic>> students = [];
      if (studentIds.isNotEmpty) {
        final studentsResponse = await Supabase.instance.client
            .from('profiles')
            .select('id, username')
            .filter('id', 'in', '(${studentIds.map((id) => "'$id'").join(',')})');
        students = (studentsResponse as List).cast<Map<String, dynamic>>();
      }

      // Build users list
      final List<Map<String, dynamic>> users = [
        {
          'id': currentUser.id,
          'username': '${staffProfile['username']} (Me)',
          'is_staff': true,
        },
        ...students.map((student) => {
          'id': student['id'].toString(),
          'username': student['username'].toString(),
          'is_staff': false,
        }),
      ];

      setState(() => _users = users);

    } catch (e) {
      print('Error in _fetchUsers: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading users: ${e.toString().split('\n').first}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _fetchProductsByCategory(String categoryId) async {
    setState(() {
      _viewingCategory = true;
    });

    try {
      final response = await Supabase.instance.client
          .from('products')
          .select()
          .eq('category_id', categoryId);

      final category = categoryData.firstWhere(
            (cat) => cat['id'] == categoryId,
        orElse: () => {'label': 'Category'},
      );

      setState(() {
        _categoryProducts = List<Map<String, dynamic>>.from(response);
        _currentCategoryName = category['label']!;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading products: $e')),
        );
      }
    }
  }

  void _backToCategories() {
    setState(() {
      _viewingCategory = false;
      _categoryProducts.clear();
    });
  }

  Future<void> _searchProducts(String query) async {
    final response = await Supabase.instance.client
        .from('products')
        .select()
        .ilike('name', '%$query%')
        .limit(20);

    setState(() {
      isSearching = true;
      searchResults = List<Map<String, dynamic>>.from(response);
    });
  }

  Future<void> _fetchPopularPicks() async {
    final response = await Supabase.instance.client
        .from('products')
        .select()
        .limit(10);
    setState(() {
      fetchedPopularPicks = List<Map<String, dynamic>>.from(response);
    });
  }

  Future<void> _fetchWishlist() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    final response = await Supabase.instance.client
        .from('wishlist_items')
        .select('product_id')
        .eq('user_id', user.id);

    setState(() {
      wishlistItemIds = {
        for (var item in response) item['product_id'].toString(),
      };
    });
  }

  Future<void> _addToWishlist(String productId) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || wishlistItemIds.contains(productId)) return;

    await Supabase.instance.client.from('wishlist_items').insert({
      'user_id': user.id,
      'product_id': productId,
    });

    _fetchWishlist();
  }

  Future<void> addToCart(String productId, int quantity) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    await Supabase.instance.client.from('cart_items').insert({
      'user_id': user.id,
      'product_id': productId,
      'quantity': quantity,
    });
  }

  Future<void> _addToSpecificUserCart(String productId, int quantity, String userId) async {
    await Supabase.instance.client.from('cart_items').insert({
      'user_id': userId,
      'product_id': productId,
      'quantity': quantity,
    });
  }

  Future<void> _addToAllUsersCarts(String productId, int quantity) async {
    for (var user in _users) {
      await Supabase.instance.client.from('cart_items').insert({
        'user_id': user['id'],
        'product_id': productId,
        'quantity': quantity,
      });
    }
  }

  void _goToCart(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => const CartScreen()));
  }

  void _goToWishlist(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => const WishlistScreen()));
  }

  void _goToAccount(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => AccountScreen()));
  }

  void _viewItem(Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) {
        int quantity = 1;
        String? selectedUserId;

        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(item['label'] ?? item['name'] ?? ''),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (item['url'] != null || item['image_url'] != null)
                      Image.network(
                        item['url'] ?? item['image_url'] ?? '',
                        height: 200,
                      ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: () {
                            if (quantity > 1) {
                              setState(() => quantity--);
                            }
                          },
                        ),
                        Text(quantity.toString(), style: const TextStyle(fontSize: 18)),
                        IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: () {
                            setState(() => quantity++);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (item.containsKey('price') && item['price'] != null)
                      Text('Price: \$${item['price']}', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 16),

                    // Staff-specific user selection
                    const Text('Add to cart for:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    DropdownButton<String>(
                      value: selectedUserId,
                      hint: const Text('Select user (optional)'),
                      isExpanded: true,
                      items: [
                        DropdownMenuItem<String>(
                          value: null,
                          child: Text('My Cart (Staff)'),
                        ),
                        ..._users
                            .where((user) => !user['is_staff']) // Only students
                            .map((user) => DropdownMenuItem<String>(
                          value: user['id'],
                          child: Text(user['username'] ?? 'Unknown User'),
                        )),
                      ],
                      onChanged: (value) {
                        setState(() => selectedUserId =value);},
                    ),
                  ],
                ),
              ),
              actions: [
                IconButton(
                  icon: Icon(
                    wishlistItemIds.contains(item['id']?.toString() ?? item['product_id']?.toString())
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: Colors.red,
                  ),
                  onPressed: () async {
                    final id = item['id']?.toString() ?? item['product_id']?.toString();
                    if (id != null) {
                      await _addToWishlist(id);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('${item['label'] ?? item['name']} added to wishlist!')),
                      );
                    }
                  },
                ),
                TextButton(
                  onPressed: () async {
                    final id = item['id']?.toString() ?? item['product_id']?.toString();
                    if (id != null) {
                      String message = '';

                      if (selectedUserId == null) {
                        // Add to staff's own cart
                        await addToCart(id, quantity);
                        message = '${item['label'] ?? item['name']} added to your cart!';
                      } else {
                        // Add to specific user's cart
                        await _addToSpecificUserCart(id, quantity, selectedUserId!);
                        final userName = _users.firstWhere((u) => u['id'] == selectedUserId)['username'];
                        message = '${item['label'] ?? item['name']} added to $userName\'s cart!';
                      }

                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(message)),
                      );
                    }
                  },
                  child: const Text("Add to Cart"),
                ),
                TextButton(
                  onPressed: () async {
                    final id = item['id']?.toString() ?? item['product_id']?.toString();
                    if (id != null) {
                      await _addToAllUsersCarts(id, quantity);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('${item['label'] ?? item['name']} added to all users\' carts!')),
                      );
                    }
                  },
                  child: const Text("Add to All Carts"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _previousPage() {
    setState(() {
      _currentPage = (_currentPage - 1 + categoryData.length) % categoryData.length;
      _pageController.animateToPage(_currentPage, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    });
  }

  void _nextPage() {
    setState(() {
      _currentPage = (_currentPage + 1) % categoryData.length;
      _pageController.animateToPage(_currentPage, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    });
  }

  void _nextPopular() {
    if (_popularIndex < fetchedPopularPicks.length - 1) {
      _popularIndex++;
      _popularController.animateToPage(
        _popularIndex,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _prevPopular() {
    if (_popularIndex > 0) {
      _popularIndex--;
      _popularController.animateToPage(
        _popularIndex,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  Widget _buildCategoryProductsView() {
    return Column(
      children: [
        // Header with back button
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: _backToCategories,
            ),
            Text(
              _currentCategoryName,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // Product Grid
        if (_categoryProducts.isEmpty)
          const Center(child: Text('No products found in this category'))
        else
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, // More columns = more compact
                childAspectRatio: 0.65, // Taller than wide
                crossAxisSpacing: 6, // Tight spacing
                mainAxisSpacing: 6,
              ),
              itemCount: _categoryProducts.length,
              itemBuilder: (context, index) {
                final product = _categoryProducts[index];
                return GestureDetector(
                  onTap: () => _viewItem(product),
                  child: Card(
                    elevation: 1,
                    margin: EdgeInsets.zero, // No external margin
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(6), // Minimal internal padding
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Image takes majority of space
                          SizedBox(
                            height: 150, // Fixed image height
                            child: product['image_url'] != null
                                ? Image.network(
                              product['image_url'],
                              fit: BoxFit.cover, // Fill the space
                            )
                                : Container(
                              color: Colors.grey[200],
                              child: const Icon(Icons.image_not_supported, size: 36),
                            ),
                          ),
                          // Compact text section
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  product['name'] ?? 'Unnamed',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  '\$${product['price'] ?? '0.00'}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.deepPurple,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  Widget _buildSearchResults() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Search Results',
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple)),
        const SizedBox(height: 12),
        if (searchResults.isEmpty)
          const Center(child: Text('No results found.'))
        else
          Expanded(
            child: ListView.builder(
              itemCount: searchResults.length,
              itemBuilder: (context, index) {
                final item = searchResults[index];
                return ListTile(
                  leading: (item['image_url'] != null && item['image_url'] != '')
                      ? Image.network(
                    item['image_url'],
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  )
                      : null,
                  title: Text(item['name'] ?? 'Unnamed product'),
                  subtitle: item.containsKey('price') && item['price'] != null
                      ? Text('\$${item['price']}')
                      : null,
                  onTap: () => _viewItem({
                    'id': item['id'].toString(),
                    'label': item['name'],
                    'url': item['image_url'],
                    'price': item['price']?.toString(),
                  }),
                );
              },
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final double imageWidth = MediaQuery.of(context).size.width * 0.9;

    return Scaffold(
      backgroundColor: const Color(0xFFF9F3FF),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFFE8D9FF),
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey[600],
        onTap: (index) {
          if (index == 1) _goToCart(context);
          if (index == 2) _goToWishlist(context);
          if (index == 3) _goToAccount(context);
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_border), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: ''),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _viewingCategory
                      ? IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: _backToCategories,
                  )
                      : const Icon(Icons.arrow_back),
                  GestureDetector(
                    onTap: () => _goToCart(context),
                    child: const Icon(Icons.shopping_cart_outlined),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text('Good morning, ${widget.username}! (Staff)',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),

              if (!_viewingCategory) const Text('This is your staff screen.'),
              const SizedBox(height: 12),

              if (!_viewingCategory) TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search products...',
                  prefixIcon: const Icon(Icons.search),
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  suffixIcon: isSearching
                      ? IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _searchController.clear();
                      setState(() {
                        isSearching = false;
                        searchResults = [];
                      });
                    },
                  )
                      : null,
                ),
              ),
              const SizedBox(height: 20),

              Expanded(
                child: isSearching
                    ? _buildSearchResults()
                    : _viewingCategory
                    ? _buildCategoryProductsView()
                    : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Categories',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.deepPurple)),
                      const SizedBox(height: 12),
                      Stack(
                        children: [
                          SizedBox(
                            height: 180,
                            child: PageView.builder(
                              controller: _pageController,
                              itemCount: categoryData.length,
                              onPageChanged: (index) {
                                setState(() => _currentPage = index);
                              },
                              itemBuilder: (context, index) {
                                final data = categoryData[index];
                                return GestureDetector(
                                  onTap: () => _fetchProductsByCategory(data['id']!),
                                  child: Column(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: Image.network(
                                          data['url']!,
                                          height: 140,
                                          width: imageWidth,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(data['label']!,
                                          style: const TextStyle(
                                              fontSize: 14, color: Colors.black87)),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 60,
                            child: IconButton(
                              icon: const Icon(Icons.arrow_back_ios),
                              onPressed: _previousPage,
                            ),
                          ),
                          Positioned(
                            right: 0,
                            top: 60,
                            child: IconButton(
                              icon: const Icon(Icons.arrow_forward_ios),
                              onPressed: _nextPage,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Popular picks',
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.deepPurple)),
                          Row(
                            children: [
                              IconButton(
                                  onPressed: _prevPopular,
                                  icon: const Icon(Icons.arrow_back_ios)),
                              IconButton(
                                  onPressed: _nextPopular,
                                  icon: const Icon(Icons.arrow_forward_ios)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 180,
                        child: fetchedPopularPicks.isEmpty
                            ? const Center(child: Text('No popular items found'))
                            : PageView.builder(
                          controller: _popularController,
                          itemCount: fetchedPopularPicks.length,
                          onPageChanged: (index) => _popularIndex = index,
                          itemBuilder: (context, index) {
                            final item = fetchedPopularPicks[index];
                            return GestureDetector(
                              onTap: () => _viewItem({
                                'id': item['id'].toString(),
                                'label': item['name'] ?? 'Unnamed',
                                'url': item['image_url'],
                                'price': item['price']?.toString(),
                              }),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                child: Column(
                                  children: [
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: item['image_url'] != null
                                          ? Image.network(
                                        item['image_url'],
                                        height: 110,
                                        width: 110,
                                        fit: BoxFit.cover,
                                      )
                                          : Container(
                                        height: 110,
                                        width: 110,
                                        color: Colors.grey[300],
                                        child: const Icon(Icons.image_not_supported),
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      item['name'] ?? 'Unnamed',
                                      style: const TextStyle(fontSize: 12),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    if (item.containsKey('price') && item['price'] != null)
                                      Text('\$${item['price']}',
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12)),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}