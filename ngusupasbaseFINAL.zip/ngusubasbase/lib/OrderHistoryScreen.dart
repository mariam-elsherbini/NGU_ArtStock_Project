import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class OrderHistoryScreen extends StatefulWidget {
  const OrderHistoryScreen({super.key});

  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  List<Map<String, dynamic>> orders = [];
  bool isLoading = true;
  String? error;

  Future<void> fetchOrderHistory() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        setState(() {
          error = "User not logged in";
          isLoading = false;
        });
        return;
      }

      // Query your orders table, adjust table and columns names accordingly
      final response = await Supabase.instance.client
          .from('orders') // or 'order_items'
          .select('id, product_id, quantity, order_date, products(name, image_url, price)')
          .eq('user_id', user.id)
          .order('order_date', ascending: false);

      setState(() {
        orders = List<Map<String, dynamic>>.from(response);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchOrderHistory();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Order History')),
        body: Center(child: Text('Error: $error')),
      );
    }

    if (orders.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Order History')),
        body: const Center(child: Text('No orders found')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Order History')),
      body: ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          final product = order['products'] ?? {};
          return ListTile(
            leading: product['image_url'] != null
                ? Image.network(product['image_url'], width: 50, height: 50, fit: BoxFit.cover)
                : const Icon(Icons.shopping_bag),
            title: Text(product['name'] ?? 'Unnamed product'),
            subtitle: Text('Quantity: ${order['quantity']}\nDate: ${order['order_date']}'),
            trailing: Text('\$${product['price'] ?? '0'}'),
          );
        },
      ),
    );
  }
}
