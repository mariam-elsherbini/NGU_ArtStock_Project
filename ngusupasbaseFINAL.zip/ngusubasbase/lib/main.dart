import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:supabase_flutter/src/constants.dart' show authFlowType;
import 'splashscreen.dart';
import 'loginscreen2.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://heyvlxmcphppjygfouxv.supabase.co',
    anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhleXZseG1jcGhwcGp5Z2ZvdXh2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc4Mjk1OTAsImV4cCI6MjA2MzQwNTU5MH0.HsBtfPTASnrf2IpE9KnBVKfW4Y54JY4erI_YlfiwU3k",
  );

  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NGU ArtStock ',
      debugShowCheckedModeBanner: false,
      home: LoginScreen2(),
    );
  }
}
