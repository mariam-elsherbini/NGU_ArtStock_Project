import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// Stateless widget for the splash screen shown at app launch
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Build the UI for the splash screen
    return Scaffold(
      // The body of the screen is centered
      body: Center(
        // Show a network image as a splash logo or welcome image
        child: Image.network(
          "https://t4.ftcdn.net/jpg/02/74/99/01/360_F_274990113_ffVRBygLkLCZAATF9lWymzE6bItMVuH1.jpg",
          height: 300, // Image height
          width: 200,  // Image width
        ),
      ),
    );
  }
}
