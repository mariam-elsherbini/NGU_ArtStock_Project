import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key});

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  Future<List<dynamic>> fetchWishlist() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];

    final response = await Supabase.instance.client
        .from('wishlist_items')
        .select('*, products(*)')
        .eq('user_id', user.id);

    return response;
  }

  Future<void> removeFromWishlist(String wishlistItemId) async {
    await Supabase.instance.client
        .from('wishlist_items')
        .delete()
        .eq('id', wishlistItemId);
    setState(() {}); // لإعادة تحميل البيانات بعد المسح
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Wishlist")),
      body: FutureBuilder<List<dynamic>>(
        future: fetchWishlist(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Your wishlist is empty."));
          }

          final wishlistItems = snapshot.data!;
          return ListView.builder(
            itemCount: wishlistItems.length,
            itemBuilder: (context, index) {
              final item = wishlistItems[index];
              return ListTile(
                leading: Image.network(item['products']['image_url'], width: 50, height: 50),
                title: Text(item['products']['name']),
                subtitle: Text('\$${item['products']['price']}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => removeFromWishlist(item['id']),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
