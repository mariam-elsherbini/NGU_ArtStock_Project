import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StaffStudentsScreen extends StatelessWidget {
  const StaffStudentsScreen({super.key});

  Future<List<dynamic>> fetchMyStudents() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];
    // Step 1: Get all student_ids for this staff from the relationship table
    final relationshipsResponse = await Supabase.instance.client
        .from('student_staff_relationships')
        .select('student_id')
        .eq('staff_id', user.id);
    final relationships = (relationshipsResponse as List).cast<
        Map<String, dynamic>>();
    final studentIds = relationships.map((r) => r['student_id'].toString())
        .toList();
    // Step 2: Fetch all student profiles
    List<Map<String, dynamic>> students = [];
    if (studentIds.isNotEmpty) {
      final studentsResponse = await Supabase.instance.client
          .from('profiles')
          .select()
          .filter('id', 'in', '(${studentIds.map((id) => "'$id'").join(',')})');
      students = (studentsResponse as List).cast<Map<String, dynamic>>();
    }
    return students;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Students')),
      body: FutureBuilder<List<dynamic>>(
        future: fetchMyStudents(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
                child: Text('No students registered with you yet.'));
          }
          final students = snapshot.data!;
          return ListView.builder(
            itemCount: students.length,
            itemBuilder: (context, index) {
              final student = students[index];
              return ListTile(
                leading: const Icon(Icons.person),
                title: Text(student['username'] ?? 'No Name'),
                subtitle: Text(student['email'] ?? ''),
                trailing: Text(student['major'] ?? ''),
              );
            },
          );
        },
      ),
    );
  }
}